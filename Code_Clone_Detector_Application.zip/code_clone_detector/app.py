import streamlit as st
import pandas as pd
from clone_detector import CodeCloneDetector, EXAMPLE_PAIRS

st.set_page_config(page_title="Code Clone Detector", page_icon="🔎", layout="wide")

st.title("🔎 Machine Learning-Based Code Clone Detector")
st.caption("Compiler Design: AST generation • Machine Learning: clone classification")

with st.sidebar:
    st.header("About this prototype")
    st.write(
        "This application parses Python snippets into Abstract Syntax Trees (ASTs), "
        "extracts structural and lexical features, and uses a supervised classifier "
        "trained on the bundled labeled examples."
    )
    st.warning(
        "This is an academic prototype, not a production plagiarism detector. "
        "The bundled dataset is small and illustrative; its scores are not evidence "
        "of real-world accuracy."
    )
    st.markdown("**Supported input:** Python code")
    st.markdown("**Clone label:** predicted by a trained Random Forest model")

@st.cache_resource
def load_detector():
    return CodeCloneDetector()

detector = load_detector()

col1, col2 = st.columns(2)
with col1:
    st.subheader("Code snippet A")
    code_a = st.text_area(
        "Paste the first Python snippet",
        value="def calculate_square(n):\n    return n * n",
        height=230,
        key="code_a",
        label_visibility="collapsed",
    )
with col2:
    st.subheader("Code snippet B")
    code_b = st.text_area(
        "Paste the second Python snippet",
        value="def square(x):\n    return x ** 2",
        height=230,
        key="code_b",
        label_visibility="collapsed",
    )

run_col, sample_col, clear_col = st.columns([1, 1, 1])
with run_col:
    analyze = st.button("Analyze code pair", type="primary", use_container_width=True)
with sample_col:
    load_example = st.button("Load another example", use_container_width=True)
with clear_col:
    clear = st.button("Clear inputs", use_container_width=True)

if load_example:
    st.session_state["example_index"] = (st.session_state.get("example_index", -1) + 1) % len(EXAMPLE_PAIRS)
    idx = st.session_state["example_index"]
    st.session_state["code_a"] = EXAMPLE_PAIRS[idx][0]
    st.session_state["code_b"] = EXAMPLE_PAIRS[idx][1]
    st.rerun()

if clear:
    st.session_state["code_a"] = ""
    st.session_state["code_b"] = ""
    st.rerun()

if analyze:
    if not code_a.strip() or not code_b.strip():
        st.error("Enter code in both boxes before analyzing.")
    else:
        result = detector.predict(code_a, code_b)
        if result["error"]:
            st.error(result["error"])
        else:
            st.divider()
            st.subheader("Prediction")
            result_col, score_col = st.columns([1, 2])
            with result_col:
                if result["is_clone"]:
                    st.success("Predicted: likely code clone")
                else:
                    st.info("Predicted: likely not a code clone")
                st.metric("Model confidence", f'{result["confidence"]:.1%}')
            with score_col:
                st.write(
                    "The prediction is based on AST-derived structural features and "
                    "lexical similarity features. It is a model estimate, not proof "
                    "that the programs are semantically equivalent or copied."
                )
                st.progress(float(result["confidence"]))

            st.subheader("Feature comparison")
            feature_df = pd.DataFrame([
                {"Feature": "AST node-count cosine similarity", "Value": f'{result["features"]["ast_node_similarity"]:.3f}'},
                {"Feature": "Normalized AST similarity", "Value": f'{result["features"]["normalized_ast_similarity"]:.3f}'},
                {"Feature": "Token similarity", "Value": f'{result["features"]["token_similarity"]:.3f}'},
                {"Feature": "Identifier-normalized AST similarity", "Value": f'{result["features"]["identifier_normalized_ast_similarity"]:.3f}'},
            ])
            st.dataframe(feature_df, hide_index=True, use_container_width=True)

            with st.expander("View generated ASTs (Compiler Design component)"):
                ast_col1, ast_col2 = st.columns(2)
                with ast_col1:
                    st.markdown("**AST for snippet A**")
                    st.code(result["ast_a"], language="text")
                with ast_col2:
                    st.markdown("**AST for snippet B**")
                    st.code(result["ast_b"], language="text")

            with st.expander("View extracted model features"):
                st.json(result["features"])

st.divider()
st.subheader("How the application works")
st.markdown("""
1. **Parse:** Python's `ast` module converts each snippet into an Abstract Syntax Tree.
2. **Normalize:** A second representation replaces variable and function names with generic labels.
3. **Extract features:** The program compares AST node distributions, normalized AST structures, and token sets.
4. **Classify:** A Random Forest classifier predicts whether the pair resembles the positive examples in the training dataset.
5. **Explain:** The interface shows the prediction, feature similarities, and ASTs.

**Important limitation:** The included training set is small and hand-curated for demonstration. Before claiming research-quality results, replace it with a larger, documented code-clone dataset, split it carefully into training and test sets, and report measured precision, recall, F1-score, and confusion matrix.
""")
