# Project implementation notes

## What is implemented
- A Streamlit web UI for comparing two Python snippets.
- AST parsing and display via Python's `ast` module.
- AST normalization and lexical/structural feature extraction.
- Random Forest classification trained on the bundled labeled examples.
- Syntax-error handling and basic feature extraction tests.

## What is not yet scientifically validated
- The bundled 40-row illustrative dataset is too small to support meaningful real-world performance claims.
- Confidence is the model's maximum class probability, not calibrated semantic-equivalence probability.
- This first version uses AST rather than a full compiler IR pipeline. If the faculty expects both AST and IR generation, we should add a dedicated IR conversion stage next.
