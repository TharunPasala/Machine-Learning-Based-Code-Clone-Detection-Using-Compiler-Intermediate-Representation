import unittest
from clone_detector import extract_features

class TestFeatureExtraction(unittest.TestCase):
    def test_similar_code_has_features(self):
        features, ast_a, ast_b = extract_features(
            "def square(n):\n return n*n",
            "def sq(x):\n return x*x",
        )
        self.assertIn("normalized_ast_similarity", features)
        self.assertGreaterEqual(features["normalized_ast_similarity"], 0.0)
        self.assertTrue(ast_a)
        self.assertTrue(ast_b)

    def test_invalid_syntax_raises(self):
        with self.assertRaises(SyntaxError):
            extract_features("def broken(:", "x = 1")

if __name__ == "__main__":
    unittest.main()
