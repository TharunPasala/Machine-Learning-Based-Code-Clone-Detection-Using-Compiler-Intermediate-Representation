import ast
import json
import math
import re
from collections import Counter
from difflib import SequenceMatcher
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.impute import SimpleImputer

DATA_PATH = Path(__file__).with_name("sample_pairs.csv")

EXAMPLE_PAIRS = [
    (
        "def is_even(n):\n    return n % 2 == 0",
        "def even_number(value):\n    if value % 2 == 0:\n        return True\n    return False",
    ),
    (
        "def add(a, b):\n    return a + b",
        "def multiply(a, b):\n    return a * b",
    ),
    (
        "def maximum(a, b):\n    if a > b:\n        return a\n    return b",
        "def largest(x, y):\n    return x if x > y else y",
    ),
]

def _parse(code):
    return ast.parse(code)

def _ast_dump(tree, normalize_identifiers=False):
    if not normalize_identifiers:
        return ast.dump(tree, annotate_fields=True, include_attributes=False)
    tree = ast.parse(ast.unparse(tree))
    class Normalize(ast.NodeTransformer):
        def __init__(self):
            self.names = {}
        def visit_Name(self, node):
            if node.id not in self.names:
                self.names[node.id] = f"VAR{len(self.names)}"
            node.id = self.names[node.id]
            return node
        def visit_arg(self, node):
            if node.arg not in self.names:
                self.names[node.arg] = f"VAR{len(self.names)}"
            node.arg = self.names[node.arg]
            return node
        def visit_FunctionDef(self, node):
            node.name = "FUNCTION"
            self.generic_visit(node)
            return node
        def visit_AsyncFunctionDef(self, node):
            node.name = "FUNCTION"
            self.generic_visit(node)
            return node
        def visit_Attribute(self, node):
            self.generic_visit(node)
            node.attr = "ATTRIBUTE"
            return node
    normalized = Normalize().visit(tree)
    ast.fix_missing_locations(normalized)
    return ast.dump(normalized, annotate_fields=True, include_attributes=False)

def _node_counts(tree):
    return Counter(type(node).__name__ for node in ast.walk(tree))

def _cosine_counter(a, b):
    keys = set(a) | set(b)
    if not keys:
        return 1.0
    dot = sum(a[k] * b[k] for k in keys)
    na = math.sqrt(sum(v * v for v in a.values()))
    nb = math.sqrt(sum(v * v for v in b.values()))
    if na == 0 or nb == 0:
        return 0.0
    return dot / (na * nb)

def _tokens(code):
    # Remove comments and string contents are retained as token-like values.
    return re.findall(r"[A-Za-z_]\w*|\d+(?:\.\d+)?|==|!=|<=|>=|//|\*\*|->|[^\s]", code)

def _jaccard(a, b):
    sa, sb = set(a), set(b)
    if not sa and not sb:
        return 1.0
    return len(sa & sb) / max(1, len(sa | sb))

def extract_features(code_a, code_b):
    tree_a = _parse(code_a)
    tree_b = _parse(code_b)
    dump_a = _ast_dump(tree_a)
    dump_b = _ast_dump(tree_b)
    norm_a = _ast_dump(tree_a, normalize_identifiers=True)
    norm_b = _ast_dump(tree_b, normalize_identifiers=True)
    tokens_a, tokens_b = _tokens(code_a), _tokens(code_b)
    counts_a, counts_b = _node_counts(tree_a), _node_counts(tree_b)
    features = {
        "ast_node_similarity": _cosine_counter(counts_a, counts_b),
        "normalized_ast_similarity": SequenceMatcher(None, norm_a, norm_b).ratio(),
        "raw_ast_similarity": SequenceMatcher(None, dump_a, dump_b).ratio(),
        "token_similarity": _jaccard(tokens_a, tokens_b),
        "token_sequence_similarity": SequenceMatcher(None, tokens_a, tokens_b).ratio(),
        "identifier_normalized_ast_similarity": SequenceMatcher(None, norm_a, norm_b).ratio(),
        "node_count_ratio": min(len(list(ast.walk(tree_a))), len(list(ast.walk(tree_b)))) / max(1, max(len(list(ast.walk(tree_a))), len(list(ast.walk(tree_b))))),
        "function_count_difference": abs(sum(isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) for n in ast.walk(tree_a)) - sum(isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) for n in ast.walk(tree_b))),
        "loop_count_difference": abs(sum(isinstance(n, (ast.For, ast.While, ast.AsyncFor)) for n in ast.walk(tree_a)) - sum(isinstance(n, (ast.For, ast.While, ast.AsyncFor)) for n in ast.walk(tree_b))),
        "branch_count_difference": abs(sum(isinstance(n, (ast.If, ast.IfExp)) for n in ast.walk(tree_a)) - sum(isinstance(n, (ast.If, ast.IfExp)) for n in ast.walk(tree_b))),
    }
    return features, dump_a, dump_b

def load_training_data(path=DATA_PATH):
    df = pd.read_csv(path)
    required = {"code_a", "code_b", "label"}
    if not required.issubset(df.columns):
        raise ValueError(f"Training data must contain columns: {sorted(required)}")
    rows, labels = [], []
    for _, row in df.iterrows():
        try:
            feats, _, _ = extract_features(str(row["code_a"]), str(row["code_b"]))
            rows.append(feats)
            labels.append(int(row["label"]))
        except (SyntaxError, ValueError, TypeError):
            continue
    if len(set(labels)) < 2:
        raise ValueError("Training data must contain examples for both labels 0 and 1.")
    return pd.DataFrame(rows).fillna(0), np.array(labels)

class CodeCloneDetector:
    def __init__(self):
        self.X, self.y = load_training_data()
        self.feature_names = list(self.X.columns)
        self.model = make_pipeline(
            SimpleImputer(strategy="median"),
            StandardScaler(),
            RandomForestClassifier(
                n_estimators=250,
                max_depth=8,
                min_samples_leaf=1,
                class_weight="balanced",
                random_state=42,
            ),
        )
        self.model.fit(self.X, self.y)

    def predict(self, code_a, code_b):
        try:
            features, ast_a, ast_b = extract_features(code_a, code_b)
        except SyntaxError as exc:
            return {"error": f"Python syntax error: {exc.msg} (line {exc.lineno})", "is_clone": False, "confidence": 0.0}
        except Exception as exc:
            return {"error": f"Could not analyze this code pair: {exc}", "is_clone": False, "confidence": 0.0}
        vector = pd.DataFrame([[features[name] for name in self.feature_names]], columns=self.feature_names)
        probabilities = self.model.predict_proba(vector)[0]
        predicted = int(self.model.predict(vector)[0])
        return {
            "error": None,
            "is_clone": predicted == 1,
            "confidence": float(max(probabilities)),
            "features": features,
            "ast_a": ast_a,
            "ast_b": ast_b,
        }

    def evaluate_training_split(self, test_size=0.25):
        X_train, X_test, y_train, y_test = train_test_split(
            self.X, self.y, test_size=test_size, random_state=42, stratify=self.y
        )
        self.model.fit(X_train, y_train)
        pred = self.model.predict(X_test)
        return {
            "accuracy": float(accuracy_score(y_test, pred)),
            "report": classification_report(y_test, pred, zero_division=0),
            "confusion_matrix": confusion_matrix(y_test, pred).tolist(),
            "test_rows": len(y_test),
        }
